# This file was automatically generated from renpy/gl/__init__.py
from __future__ import print_function

# Modifications will be automatically overwritten.
